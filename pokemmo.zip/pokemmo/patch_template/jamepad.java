package com.badlogic.gdx.controllers.desktop;

import f.{extends};
import f.{listener_type};

public class JamepadControllerManager extends {extends} {{

  public JamepadControllerManager() {{
    // No-op constructor
  }}

  public static void addMappingsFromFile(String str) {{
    // No-op
  }}

  public static void logLastNativeGamepadError() {{
    // No-op
  }}

  @Override
  public void addListener({listener_type} listener) {{
    // No-op
  }}

  public void removeListener(Object listener) {{
    // No-op
  }}

  public Object getListeners() {{
    // Return empty object or null
    return null;
  }}

  public void clearListeners() {{
    // No-op
  }}

  public void dispose() {{
    // No-op
  }}
}}

